public class Edge {
    //int bobot;
    Edge next;
    Vertex goal;
    Edge(){
        next = null;
        goal = null;
    }
}
